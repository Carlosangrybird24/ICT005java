package Unicentre;
import java.util.Scanner;
public class Loop1_Q2 {

	public static void main(String[] args) {
		//100 이하 의 정수를 입력받아서 입력받은 정수부터 100까지의
		//합을 출력하는 프로그램을 작성하시오 >> 입력 95 출력 585

		Scanner sc=new Scanner(System.in);
		int num=0;
		int sum=0;
		int count=0;

		if(count<=100) {
			num=sc.nextInt();

			for (int i=num; i<100+1; i++) {
				sum+=i; 
			} 
			System.out.println(sum);
		}
		sc.close();
	}

}
