package Unicentre;
import java.util.Scanner;

public class Loop1_Q4 {

	public static void main(String[] args) {  
		//100 이하 의 양의 정수만 입력 된다.
		//while문을 이용하여 1부터 입력받은 정수까지의 합을 
		//구하여 출력하는 프로그램 작성 입력10 출력 55

		Scanner sc=new Scanner(System.in);

		int num = sc.nextInt();
		int count=0;
		int sum=0;

		if (num>=0 && num<=100) {
			while(count<=num) {
				sum+=count;
				count++;
			}
			System.out.println(sum);
		}
		sc.close(); 
	} 
}
