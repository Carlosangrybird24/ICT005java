package Unicentre;
import java.util.Scanner;
public class Loop1_Q1 {

	public static void main(String[] args) {
		//100 이하 의 양의 정수만 입력된다.
		//while 문을 이용해 1부터 입력받은 정수까지의 합을 구해 출력 작성 
		//입력 10 출력 55
		int sum=0;
		int num=0;
		int start=0;
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		if (num<=100) {
			while(start<num) { 
				start++;
				sum+=start;
			} System.out.println(sum);
		}
		sc.close();
	} 
}
