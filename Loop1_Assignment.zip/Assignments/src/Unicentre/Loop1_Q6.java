package Unicentre;
import java.util.Scanner;

public class Loop1_Q6 {
	public static void main(String[] args) { 
		//삼각형의 밑변의 길이와 높이를 입력받아 넓이를 출력하고,
		//continue? 에서 하나의 문자를 입력받아 그문자가 y 또느 Y 이면작업을 반복하고
		//다른문자이면 종료하는 프로그램을 작성하시오 
		//(넓이는 반올림 하여 소수 첫째자리 까지 출력한다 )
		Scanner sc=new Scanner(System.in);
		String again=null;
		while(true) {
			System.out.print("Base = ");
			double base=sc.nextDouble();
			System.out.print("Height = ");
			double height=sc.nextDouble();
			double triangleArea=Math.round(((base*height)/2)*100)/100.0;
			System.out.println("Triangle width = "+triangleArea);
			System.out.print("Continue? ");
			again=sc.next(); 
			
			if (again.equals("Y")==true || again.equals("y")==true) {
				continue;
			}
			 else if (again.equals("Y")!=true || again.equals("y")!=true) {
				break;
			}
		}
		sc.close();
		//입력출력
		//Base=11 
		//Height=5
		//Triangle width=27.5
		//Continue? Y 
		//Base=10
		//height=10
		//Triangle width=50.0
		//continue? N
	}
}
