package Unicentre;
import java.util.Scanner;
public class Loop1_Q5 {
	public static void main(String[] args) {
		//0 이 입력될 때까지 정수를 계속 입력받아 3의 배수와 5의 배수를
		//제외한 수들의 개수를 출력하는 프로그램을 작성하시오. 
		//>> 입력 1 2 3 4 5 6  7 8 9 10 0  출력 5 
		Scanner sc=new Scanner(System.in);

		int count=0;
		int countAll=0;
		
		while (true) {
			int num=sc.nextInt(); 
			if (num==0) {
				break;
			}
			else if (num!=0){ 
				if (num%3==0 && num%5!=0 || num%5==0) {
					count++; 
				}
			}
			countAll++;
		}
		count=countAll-count;
		System.out.println(count);
		sc.close();
	}
}
