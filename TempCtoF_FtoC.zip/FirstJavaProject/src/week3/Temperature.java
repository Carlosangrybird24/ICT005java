package week3;
import java.util.Scanner;
public class Temperature {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("===================");
		System.out.println("1. 화씨 -> 섭씨");
		System.out.println("2. 섭씨 -> 화씨");
		System.out.println("===================");
		
		System.out.print("번호를 선택하세요 :");
		int choices=sc.nextInt();
		
		if (choices==1) {
			System.out.print("화씨온도를 입력하세요 : ");
			double temp=sc.nextDouble();

			double FtoC=5.0/9.0*(temp-32.0);
			System.out.println("섭씨온도는 "+FtoC);
		}
		else if(choices==2) {
			System.out.print("섭씨온도를 입력하세요 : ");
			double temp=sc.nextDouble();

			double CtoF=(temp*(9.0/5.0))+32.0;
			System.out.println("화씨온도는 "+CtoF);

		}
		else {
			System.out.println("유효하지 않는 입력값입니다.");
		}
	}
}
