package Unicentre;
import java.util.Scanner;
public class Loop2_Q8 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		int q=1;
		for (int i=num; i>0; i--) {
			for (int x=num; x>i; x--) {
				System.out.print(" "+" ");
			} 
			for (int j=1; j<i+1; j++) {

				System.out.print(q+" ");
				q++;
			}System.out.println();
		}
		sc.close();
	}

}