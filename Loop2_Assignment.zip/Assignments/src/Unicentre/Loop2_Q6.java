package Unicentre;
import java.util.Scanner;
public class Loop2_Q6 {
	public static void main(String[] args) {
		//1부터 100까지의 정수중 한 개를 입력받아 100보다 작은 배수들을 차례로 
		//출력하다가 10의 배수가 출력되면 프로그램을 종료하도록 프로그램을 작성하시오. 
		//>>입력 7 출력 7 14 21... 70 

		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();

		for(int i=num; ;i+=num) {
			System.out.print(i+" ");
			if (i%10==0) {
				break;
			}
		}
		sc.close();
	}

}
