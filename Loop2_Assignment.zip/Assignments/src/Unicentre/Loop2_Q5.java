package Unicentre;
import java.util.Scanner;

public class Loop2_Q5 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();


		for(int i=0; i<num+1; i++) {
			for (int j=0; j<i; j++) {
				System.out.print(" ");
			}
			for (int j=num; j+1>i*2-1; j--) {
				System.out.print("*");
			}		
			System.out.println();
		}
		sc.close();
	}

}
