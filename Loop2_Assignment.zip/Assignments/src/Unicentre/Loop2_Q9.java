package Unicentre;
import java.util.Scanner;
public class Loop2_Q9 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);

		int num = sc.nextInt();
		int w=1;
		for( int i = 0; i<num; i++) {
			for(int j=0; j<num; j++) {
				if (w>10) {
					w=1;
				}
				System.out.print(w+" ");
				w+=2;
			}System.out.println();
		}
		sc.close();
	}

}
