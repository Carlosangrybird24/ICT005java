package Unicentre;
import java.util.Scanner;
public class Loop2_Q7 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();

		for (int i=0; i<num; i++) {
			for(int j=num; j-1>i; j--) {
				System.out.print(" "+" ");
			}
			for(int k=1; k<i+2; k++) {
				System.out.print(k+" ");
			}

			System.out.println();
		}
		sc.close();
	}

}
