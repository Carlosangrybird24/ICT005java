package Unicentre;

import java.util.Scanner;

public class Array_Q7 {
	public static void main(String[] args) {
		//100미만의 양의 정수들이 주어진다. 입력받다가 0이 입력되면 마지막에 입력된 0 을 제외하고 
		//그 떄까지 입력된 정수의 십의 자리 숫자가 각각 몇 개인지 작은 수부터 출력하는 프로그램을 작성하시오. 
		//(0개인 숫자는 출력하지 않는다.)			0:1
		//입력 : 10 55 3 63 85 61 85 0  출력   1:1
		//								    5:1
		//									6:2
		//									8:2
		Scanner sc = new Scanner(System.in);
		int num=0,num0=0,num1=0,num2=0,num3=0,num4=0,
			num5=0,num6=0,num7=0,num8=0,num9=0,num10=0;
		while(true) {num=sc.nextInt();
			if (num<100 && num!=0) {
				num10=num/10;
				switch(num10) {
				case 9: num9++; break;
				case 8: num8++; break;
				case 7: num7++; break;
				case 6: num6++; break;
				case 5: num5++; break;
				case 4: num4++; break;
				case 3: num3++; break;
				case 2: num2++; break;
				case 1: num1++; break;
				case 0: num0++; break;
				}
			}
			else if(num==0) {
				if (num0!=0) {System.out.println("0 : "+ num0);}
				if (num1!=0) {System.out.println("1 : "+ num1);}
				if (num2!=0) {System.out.println("2 : "+ num2);}
				if (num3!=0) {System.out.println("3 : "+ num3);}
				if (num4!=0) {System.out.println("4 : "+ num4);}
				if (num5!=0) {System.out.println("5 : "+ num5);}
				if (num6!=0) {System.out.println("6 : "+ num6);}
				if (num7!=0) {System.out.println("7 : "+ num7);}
				if (num8!=0) {System.out.println("8 : "+ num8);}
				if (num9!=0) {System.out.println("9 : "+ num9);}
				break;
			}
		}sc.close();
	}
}
