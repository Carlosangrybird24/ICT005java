package Unicentre;
import java.util.Scanner;
public class Array_Q5 {
	public static void main(String[] args) { 
		//100개의 정수를 저장할 수 있는 배열 선언하고  정수를 차례로 입력받다가 0 이 입력되면 0을 제외하고
		//그때까지 입력된 정수를 가장 나중에 입력된 정수부터 차례대로 출력하는 프로그램을 작성하시오
		//입력  3 5 10 55 0 출력 55 10 5 3
		int[] num= new int[100];
		Scanner sc=new Scanner(System.in);

		for(int i=0; i<num.length; i++) {
			num[i]=sc.nextInt();
			if(num[i]==0) {
				break;
			}
		}

		for(int i=num.length-1; i>=0; i--) {
			if (num[i]!=0) {
				System.out.print(num[i]+" ");
			}
		}
		sc.close();
	}

}
