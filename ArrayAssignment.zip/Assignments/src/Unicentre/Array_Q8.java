package Unicentre;
import java.util.Scanner;
public class Array_Q8 {

	public static void main(String[] args) {
		//2행 4열의 배열 2개를 만들어서 입력을 받고 두배열의 곱을 구하여 출력하는 프로그램을 작성하시오.
		//first array   second array        출력
		// 1 2 3 4 		  1 4 7 8		1 8 21 32
		// 5 6 7 8        3 6 9 8       15 36 63 64
		Scanner sc = new Scanner(System.in);

		System.out.println("first array");
		int [][] firstArray= new int[2][4];
		for (int i=0; i<firstArray.length; i++) {
			for (int j=0; j<firstArray[i].length; j++) {
				firstArray[i][j]=sc.nextInt();
			}
		}System.out.println();
		
		System.out.println("second array");
		int [][] secondArray= new int[2][4];
		for (int i=0; i<secondArray.length; i++) {
			for (int j=0; j<secondArray[i].length; j++) {
				secondArray[i][j]=sc.nextInt();
			}
		}System.out.println();
		
		System.out.println("Output ");
		int [][] thirdArray= new int[2][4];
		for (int i=0; i<thirdArray.length; i++) {
			for (int j=0; j<thirdArray[i].length; j++) {
				thirdArray[i][j]=firstArray[i][j] * secondArray[i][j]  ;
				System.out.print(thirdArray[i][j]+" ");
			}System.out.println();
		}
		sc.close();
	}
}

//int [][] firstArray= new int[2][4];
//for (int i=0; i<firstArray.length; i++) {
//	for (int j=0; j<firstArray[i].length; j++) {
//		if (i==0) {
//			System.out.print(1+i+j+" ");
//		}
//		else {
//			System.out.print(4+i+j+" ");
//		}
//	}System.out.println();
//}
//System.out.println();

//System.out.println("second array");
//
//int [][] secondArray= new int[2][4];
//secondArray[0][0]=1;
//secondArray[0][1]=4;
//secondArray[0][2]=7;
//secondArray[0][3]=8;
//secondArray[1][0]=3;
//secondArray[1][1]=6;
//secondArray[1][2]=9;
//secondArray[1][3]=8;
//
//
//for (int i=0; i<secondArray.length; i++) {
//	for (int j=0; j<secondArray[i].length; j++) {
//		System.out.print(secondArray[i][j]+" ");
//	}System.out.println();
//}


//System.out.println("third");
//
//int [][] thirdArray= new int[2][4];
//for (int i=0; i<thirdArray.length; i++) {
//	for (int j=0; j<thirdArray[i].length; j++) {
//		if (i==0) {
//			if (j==thirdArray[i].length-1) {
//				System.out.print(8+" ");	
//			}
//			else {
//				System.out.print(1+i+j*3+" ");
//			}
//		}
//		else if (j==thirdArray[i].length-1) {
//			System.out.print(8+" ");	
//		}
//		else {
//			System.out.print(3*(j+1)+" ");
//		}
//	}System.out.println();
//}