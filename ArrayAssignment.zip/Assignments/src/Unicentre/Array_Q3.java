package Unicentre;
import java.util.Scanner;
public class Array_Q3 {
	public static void main(String[] args) {
		//1반부터 6반까지 평균점수를 저장한 후 두 반 번호를 입력받아 두 반 평균점수의 합을 출력하는 프로그램 작성
		//반별 평균점수는 초기값으로 1반부터 차례로 85.6 79.5 83.1 80.0 78.2 75.0 으로 초기화 하고 
		//출력은 소수 두번째 자리에서 반올림 하여 소수 첫째 자리까지한다.
		//입력 1 3  출력 168.7
		Scanner sc=new Scanner(System.in);

		double[] avg = {85.6, 79.5, 83.1, 80.0, 78.2, 75.0 };

		double sum =avg[sc.nextInt()-1]+avg[sc.nextInt()-1];
		sum=Math.round(sum*100)/100.0;

		System.out.println(sum);
		sc.close();
	}



}
