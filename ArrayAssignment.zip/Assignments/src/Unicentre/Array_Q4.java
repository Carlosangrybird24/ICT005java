package Unicentre;

import java.util.Scanner;

public class Array_Q4 {

	public static void main(String[] args) {
		//10개의 정수를 입력받아 배열에 저장한 후 짝수 번째 입력된 값의 합과 홀수 번째 입력된 값의 평균을 출력하는 프로그램을 작성하시오. 
		//평균은 반올림하여 소수첫째자리까지 출력. 
		//입력 95 100 88 65 76 89 58 93 77 99  출력 sum: 446 avg : 78.8
		//    0  1   2  3  4  5  6  7  8  9     1,3,5,7,9
		Scanner sc = new Scanner(System.in);
		int[] num=new int[10];
		double sum=0;
		double sum2=0;
		double count=0;
		
		for (int i=0; i<10; i++) {
			num[i]=sc.nextInt(); 
			if(i==1 || (i+1)%2==0) {
				sum+=num[i];
			}
			else {
				sum2+=num[i];
				count++;
			}
		}
		double avg2= sum2/count;
		System.out.println("짝수 sum : "+sum); 
		System.out.println("홀수 avg : "+avg2); 

		sc.close();
	}
}
