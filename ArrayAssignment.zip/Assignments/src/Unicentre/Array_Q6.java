package Unicentre;

import java.util.Scanner;

public class Array_Q6 {

	public static void main(String[] args) {
		// 10개의 정수를 입력받아 그 중 가장 적은 수를 출력하는 프로그램을 작성하시오. 
		//(입력받을정수는 1000이하) 입력 5 10 8 55 6 31 12 24 61 2 출력 2
		Scanner sc = new Scanner(System.in);
		int[] num = new int[10]; 

		for (int i=0; i< num.length; i++) {
			num[i]=sc.nextInt();
			if (num[i]>1000) {
				System.out.println("1000보다 높게 입력하였습니다, 종료.");
				break;
			}
		}
		int a = num[0];
		int b = num[0];

		for (int j=1; j< num.length; j++) {
			if (a>num[j]) {
				a=num[j];
			}
			else if(b<num[j]) {
				b=num[j];
			}
		}
		if (b<1000) {
			System.out.println(a);
		}
		sc.close();
	}
}