package Unicentre;

import java.util.Scanner;

public class Array_Q9 {
	public static void main(String[] args) {
		//호식이네 학교는 6학년이 네 반이 있는데 각 반의 대표를 세 명씩 선발하여 제기차기 시합을 하였다.
		//반별로 세 명이 제기를 찬 개수를 입력받아 각 반별로 제기를 찬 개수의 합계를 출력하는 프로그램을 작성하시오. 
		//(반드시배열 이용하고 입력후에 출력방식이용) 					 출력 
		//    1class? 15 2 35 						1class : 52 
		//	  2class? 33 1 6 						2class : 40
		//    3class? 5 10 19						3class : 34
		//    4class? 1  8 55     				    4class : 64
		Scanner sc = new Scanner(System.in);
		
		int[][] class6 = new int[4][3];
		
		for(int i=0; i<class6.length; i++) {
				System.out.print(i+1+"class? ");
			for(int j=0; j<class6[i].length; j++) {
				class6[i][j]=sc.nextInt();
				
			}
		}
		System.out.println();
		int sum=0;
		for(int q=0; q<class6.length; q++) {
				System.out.print(q+1+"class : ");
			for(int w=0; w<class6[q].length; w++) {
				sum+=class6[q][w];
			}System.out.println(sum);
			 sum=0;
		}
		sc.close();
	}
}
