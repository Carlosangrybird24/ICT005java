package Unicentre;

import java.util.Scanner;

public class Array_Q2 {
	public static void main(String[] args) {
		// 6명의 몸무게를 입력받아 평균을 출력하는 프로그램 작성
		// 출력은 반올림 첫째 자리까지 
		Scanner sc=new Scanner(System.in);

		double[] num=new double[6];
		double sum=0;
		for (int i=0; i<num.length; i++) {
			num[i]=sc.nextDouble();
			sum+=num[i];
		}
		double avg=sum/num.length;
		System.out.println(Math.round(avg*10)/10.0);
		sc.close();
		}
}
