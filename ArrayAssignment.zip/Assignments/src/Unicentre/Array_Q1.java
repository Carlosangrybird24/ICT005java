package Unicentre;

import java.util.Scanner;

public class Array_Q1 {

	public static void main(String[] args) {
		// 10개의 문자를 입력받아서 첫 번째 네 번째 일곱 번째 입력받은 문자를 차례로 출력하는 프로그램 작성 
		// 입력 A B C D E F G H I J 출력 A D G
		//    0 1 2 3 4 5 6 7 8 9     0 3 6
		Scanner sc=new Scanner(System.in);
		
		String [] num= new String[10];
		for (int i=0; i<num.length; i++) {
			num[i]=sc.next();


			if (i==0 || i%3==0 && i%9!=0) {
				System.out.print(num[i]+" ");
			}
		}
		sc.close();
	}

}
