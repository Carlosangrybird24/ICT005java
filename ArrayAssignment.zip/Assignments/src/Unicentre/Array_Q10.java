package Unicentre;

import java.util.Scanner;

public class Array_Q10 {
	public static void main(String[] args) {
		//4행 2열의 배열을 입력받아 가로평균과 세로평균 그리고 전체평균을 출력하는 프로그램을 작성하시오.
		//(소수점 이하는 버림 한다.)   입력 16 27		출력	21 69 53 40
		//						   39 100			33 58
		//						   19 88			46
		// 						   61 20     
		Scanner sc = new Scanner(System.in);

		int[][] num = new int [4][2];
		for(int i=0; i<num.length; i++) {
			for(int j=0; j<num[i].length; j++) {
				num[i][j]=sc.nextInt();
			}	
		}

		int allAvg=0;
		int count=0;
		for(int i=0; i<num.length; i++) {
			int sum=0;
			for(int j=0; j<num[i].length; j++) {
				sum+=num[i][j];
				allAvg+=num[i][j];
				count++;
			}
			sum=sum/num[i].length;
			System.out.print(Math.round(Math.floor(sum))+" ");
		}	System.out.println();

		for(int i=0; i<2; i++) {
			int sum2=0;
			for(int j=0; j<4; j++) {
				sum2+=num[j][i];
			}sum2=sum2/num.length;
			 System.out.print(Math.round(Math.floor(sum2))+" ");
		}	 System.out.println();
			 allAvg=allAvg/count;
			 System.out.println(Math.round(Math.floor(allAvg)));
			 sc.close();
	}
}

