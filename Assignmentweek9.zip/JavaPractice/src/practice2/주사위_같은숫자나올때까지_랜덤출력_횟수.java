package practice2;

public class 주사위_같은숫자나올때까지_랜덤출력_횟수 {

	public static void main(String[] args) { 
		int count=0;
		
		주사위 dice=new 주사위(); 

		while(true) {
			dice.setValue();
			System.out.println(dice);
			count++;
			if(dice.getValue1()==1 && dice.getValue2()==1) {
				System.out.println("(1,1)이 나오는데 걸린 횟수= "+count);
				break;
			}
		}
	}

} 