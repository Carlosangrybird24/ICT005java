package practice2;
import java.math.*;

public class 주사위 {

	private int value1;
	private int value2;
	
	public 주사위() {
		value1=0;
		value2=0;
	}

	public int getValue1() {
		return value1;
		
	}
	public int getValue2() {
		return value2;
		
	}
	
	public void setValue() {
	 this.value1=randomNum();
	 this.value2=randomNum();
	}
	
	public String toString() {
		return "주사위1= "+value1+"    주사위2= "+value2;
	}
	
	public static int randomNum() {
		return (int)(Math.random()*6);
}
}